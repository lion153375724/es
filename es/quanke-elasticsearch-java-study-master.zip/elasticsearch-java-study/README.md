
# Elasticsearch Java API 手册 示例


### Elasticsearch Java API 手册：

阅读地址：[https://es.quanke.name](https://es.quanke.name)

下载地址：[https://www.gitbook.com/book/quanke/elasticsearch-java](https://www.gitbook.com/book/quanke/elasticsearch-java)

github地址：[https://github.com/quanke/elasticsearch-java](https://github.com/quanke/elasticsearch-java)

gitee 地址：[https://gitee.com/quanke/elasticsearch-java](https://gitee.com/quanke/elasticsearch-java) 

配套示例代码：[https://gitee.com/quanke/elasticsearch-java-study](https://gitee.com/quanke/elasticsearch-java-study)



> 需要切换不同的Client,只需要 extends 不同的 Client

```java

package name.quanke.es.study;

/**
 * Created by http://quanke.name on 2017/11/10.
 */
public abstract class ElasticsearchClientBase extends  ElasticsearchClient{

}

````


更多请关注我的微信公众号（keatingr）：

![](/assets/qrcode_for_gh_26893aa0a4ea_258.jpg)